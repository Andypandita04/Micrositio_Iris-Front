// api/ApiClient.js
import axios from 'axios';

class ApiClient {
  constructor(baseURL) {
    this.client = axios.create({
      baseURL,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // Configurar interceptor para JWT (si es necesario)
    /** 
    this.client.interceptors.request.use((config) => {
      const token = localStorage.getItem('token');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      return config;
    });

    // Manejo centralizado de errores
    this.client.interceptors.response.use(
      (response) => response,
      (error) => {
        if (error.response) {
          throw new Error(
            error.response.data.message || 'Error en la solicitud al servidor'
          );
        } else {
          throw new Error('Error de conexión con el servidor');
        }
      }
    );*/
  }

  // --- Proyectos ---
  async crearProyecto(data) {
    return this.client.post('/proyectos', data);
  }

  async obtenerProyecto(id) {
    return this.client.get(`/proyectos/${id}`);
  }

  async actualizarProyecto(id, data) {
    return this.client.put(`/proyectos/${id}`, data);
  }

  async eliminarProyecto(id) {
    return this.client.delete(`/proyectos/${id}`);
  }

  async listarProyectos(filtros = {}) {
    const params = new URLSearchParams();
    if (filtros.estado) params.append('estado', filtros.estado);
    if (filtros.titulo) params.append('titulo', filtros.titulo);
    return this.client.get(`/proyectos?${params.toString()}`);
  }

  /** 
  async agregarColaborador(proyectoId, colaboradorId) {
    return this.client.post(`/proyectos/${proyectoId}/colaboradores`, {
      colaboradorId,
    });
  }

  async eliminarColaborador(proyectoId, colaboradorId) {
    return this.client.delete(
      `/proyectos/${proyectoId}/colaboradores/${colaboradorId}`
    );
  }

  // --- Métodos genéricos para reutilización ---
  async get(endpoint, params = {}) {
    return this.client.get(endpoint, { params });
  }

  async post(endpoint, data) {
    return this.client.post(endpoint, data);
  }

  async put(endpoint, data) {
    return this.client.put(endpoint, data);
  }

  async delete(endpoint) {
    return this.client.delete(endpoint);
  }
}*/

// Instancia Singleton
const apiClient = new ApiClient(process.env.REACT_APP_API_URL || 'http://localhost:3000/api');

export default apiClient;